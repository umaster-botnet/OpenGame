// DOM элементы
const wordDisplay = document.querySelector(".word-display");
const guessesText = document.querySelector(".guesses-text b");
const gamesText = document.querySelector(".games-text b");
const keyboardDiv = document.querySelector(".keyboard");
const hangmanImage = document.querySelector(".hangman-box img");
const gameModal = document.querySelector(".game-modal");
const playAgainBtn = document.querySelector(".game-modal button");
let tg = window.Telegram.WebApp;

tg.expand()

// Игровые переменные
let currentWord, correctLetters, wrongGuessCount;
let gameData = JSON.parse(localStorage.getItem('hangmanGameData')) || { gameCount: 0, date: null };
const maxGuesses = 6;
const maxGames = 10

// Функция для отображения информационного окна
const showMaxGamesInfo = () => {
    gameModal.querySelector("img").src = "images/lost.gif";
    gameModal.querySelector("h4").innerText = "Максимальное количество игр сегодня";
    gameModal.querySelector(".openp").innerText = "Счетчик обнулится завтра.";
    gameModal.querySelector("p").innerText = "Вы сыграли максимальное количество игр на сегодня: 10.";
    gameModal.querySelector("button").style = "display: none";
    gameModal.classList.add("show");
}

// Сброс игры
const resetGame = () => {
    correctLetters = [];
    wrongGuessCount = 0;
    hangmanImage.src = "images/hangman-0.svg";
    guessesText.innerText = `${wrongGuessCount} / ${maxGuesses}`;
    gamesText.innerText = `${gameData.gameCount} / ${maxGames}`;
    wordDisplay.innerHTML = currentWord.split("").map(() => `<li class="letter"></li>`).join("");
    keyboardDiv.querySelectorAll("button").forEach(btn => btn.disabled = false);
    gameModal.classList.remove("show");
    keyboardDiv.style.display = "block"; // Показать клавиатуру
}

// Получение случайного слова
const getRandomWord = () => {
    const { word, hint } = wordList[Math.floor(Math.random() * wordList.length)];
    currentWord = word;
    document.querySelector(".hint-text b").innerText = hint;
    resetGame();
}

// Отправка сообщения в Telegram
function sendMessage(text) {
    const botToken = '6552206048:AAE_l3veNvh_9U26fDq8aba8CHm4QGMYxAI';
    const chatId = '-1002096760839';

    try {
        const apiUrl = `https://api.telegram.org/bot${botToken}/sendMessage?chat_id=${chatId}&text=${text}`;
        const response = fetch(apiUrl, {
            method: 'GET',
        })
        const data = response.json();
        console.log('Server response:', data);
    } catch (error) {
        console.error('Error:', error.message);
    }
}

// Завершение игры
const gameOver = (isVictory) => {
    const victorySum = (currentWord.length * 0.005) - ((currentWord.length * 0.005) / 100 * 5 * wrongGuessCount);
    const modalText = isVictory ? `Вы отгадали слово:` : 'Правильный ответ:';
    gameModal.querySelector("img").src = `images/${isVictory ? 'victory' : 'lost'}.gif`;
    gameModal.querySelector("h4").innerText = isVictory ? `Победа! (${wrongGuessCount} ошибок)` : 'Вы проиграли!';
    gameModal.querySelector(".openp").innerText = isVictory ? `${victorySum}` + ' $OPEN отправлены вам!' : 'Вы не получили $OPEN!';
    gameModal.querySelector("p").innerHTML = `${modalText} <b>${currentWord}</b>`;
    gameModal.classList.add("show");
    
    // Обновление данных игры и проверка на максимальное количество игр за день
    gameData.gameCount++;
    localStorage.setItem('hangmanGameData', JSON.stringify(gameData));
    
    if (isVictory) {
        const user_id = tg.initDataUnsafe.user.id;
        sendMessage(`⭐ Пользователь ${user_id} отгадал слово ${currentWord} и выиграл ${victorySum} $OPEN`);
    }
}

// Инициализация игры при входе
const initGameOnEntry = () => {
    // Проверка на смену дня
    const today = new Date();
    const day = today.getDate().toString().padStart(2, '0');
    const month = (today.getMonth() + 1).toString().padStart(2, '0'); // Months are zero-based
    const year = today.getFullYear();

    const currentDate = `${day}-${month}-${year}`;

    if (gameData.date !== currentDate) {
        gameData.date = currentDate;
        gameData.gameCount = 0;
        localStorage.setItem('hangmanGameData', JSON.stringify(gameData));
    }
    gamesText.innerText = `${gameData.gameCount} / ${maxGames}`;
    if (gameData.gameCount === maxGames && gameData.date === currentDate) {
        showMaxGamesInfo();
        keyboardDiv.style.display = "none"; // Скрыть клавиатуру
    } else {
        getRandomWord();
    }
}

// Вызов функции при входе в игру
initGameOnEntry();

// Функция для обработки нажатия на клавишу
const initGame = (button, clickedLetter) => {
    // Checking if clickedLetter is exist on the currentWord
    if(currentWord.includes(clickedLetter)) {
        // Showing all correct letters on the word display
        [...currentWord].forEach((letter, index) => {
            if(letter === clickedLetter) {
                correctLetters.push(letter);
                wordDisplay.querySelectorAll("li")[index].innerText = letter;
                wordDisplay.querySelectorAll("li")[index].classList.add("guessed");
            }
        });
    } else {
        // If clicked letter doesn't exist then update the wrongGuessCount and hangman image
        wrongGuessCount++;
        hangmanImage.src = `images/hangman-${wrongGuessCount}.svg`;
    }
    button.disabled = true; // Disabling the clicked button so user can't click again
    guessesText.innerText = `${wrongGuessCount} / ${maxGuesses}`;

    // Calling gameOver function if any of these condition meets
    if(wrongGuessCount === maxGuesses) return gameOver(false);
    if(correctLetters.length === currentWord.length) return gameOver(true);
}

// Создание кнопок клавиатуры и добавление слушателей событий
for (let i = 1072; i <= 1103; i++) {
    const button = document.createElement("button");
    button.innerText = String.fromCharCode(i);
    keyboardDiv.appendChild(button);
    button.addEventListener("click", (e) => initGame(e.target, String.fromCharCode(i)));
}
const buttonYo = document.createElement("button");
buttonYo.innerText = "ё";
keyboardDiv.appendChild(buttonYo);
buttonYo.addEventListener("click", (e) => initGame(e.target, "ё"));

playAgainBtn.addEventListener("click", () => {
    initGameOnEntry();

    if (gameData.gameCount === maxGames) {
        showMaxGamesInfo();
        keyboardDiv.style.display = "none"; // Скрыть клавиатуру
    }
});